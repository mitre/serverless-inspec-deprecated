module Bundler; end
require 'bundler/vendor/thor/lib/thor'
require 'bundler/vendor/thor/lib/thor/actions'
